install.packages("did")
install.packages("foreign")
install.packages("ggplot2")
install.packages("janitor")
install.packages("haven")

library(did)
library(foreign)
library(ggplot2)
library(janitor)
library(haven)

sex_ed_comp <- read.dta("folder/data/analytic_sample.dta")

set.seed(1814)
comp_nor <- att_gt(yname = "demn_lnbrate",
                     tname = "year",
                     idname = "county_res",
                     gname = "comp_fund_first",
                     weightsname = "pop",
                     control_group = "nevertreated",
                     clustervars = "county_res",
                     est_method = "reg",
                     data = sex_ed_comp
)

set.seed(1814)
comp_attgt <- att_gt(yname = "demn_lnbrate",
                    tname = "year",
                    idname = "county_res",
                    gname = "comp_fund_first",
                    weightsname = "pop",
                    xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                    + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                    + pct_16_19_2010, 
                   control_group = "nevertreated",
                    clustervars = "county_res",
                   est_method = "reg",
                    data = sex_ed_comp
)

summary(comp_nor)
set.seed(1814)
agg.group.comp.nor <- aggte(comp_nor, type = "group", na.rm=TRUE)
summary(agg.group.comp.nor, na.rm=TRUE)
summary(comp_attgt)
set.seed(1814)
agg.group.comp <- aggte(comp_attgt, type = "group", na.rm=TRUE)
summary(agg.group.comp, na.rm=TRUE)


df.agg.group.comp <-data.frame(agg.group.comp$overall.att, agg.group.comp$overall.se, agg.group.comp$crit.val.egt)
df.agg.group.comp<-janitor::clean_names(df.agg.group.comp)
write_dta(df.agg.group.comp, "folder/data/agg_group_comp.dta", version = 12)


df.agg.group.comp.nor <-data.frame(agg.group.comp.nor$overall.att, agg.group.comp.nor$overall.se, agg.group.comp.nor$crit.val.egt)
df.agg.group.comp.nor <-janitor::clean_names(df.agg.group.comp.nor)
write_dta(df.agg.group.comp.nor, "folder/data/agg_group_comp_noR.dta", version = 12)

set.seed(1814)
agg.dynamic.comp <- aggte(comp_attgt, type = "dynamic", na.rm=TRUE)
summary(agg.dynamic.comp)

set.seed(1814)
agg.dynamic.comp.nor <- aggte(comp_nor, type = "dynamic", na.rm=TRUE)
ggdid(agg.dynamic.comp.nor)

ggdid(agg.dynamic.comp)+ggtitle("More Comprehensive")+xlim(-15, 6)
df.agg.dynamic.comp <-data.frame(agg.dynamic.comp$egt, agg.dynamic.comp$att.egt, agg.dynamic.comp$se.egt, agg.dynamic.comp$crit.val.egt)
df.agg.dynamic.comp <-janitor::clean_names(df.agg.dynamic.comp)
write_dta(df.agg.dynamic.comp, "folder/data/agg_dynamic_comp.dta", version = 12)

##########################################################
####Appendix
##########################################################
#unweighted
set.seed(1814)
comp_uw <- att_gt(yname = "demn_lnbrate",
                          tname = "year",
                          idname = "county_res",
                        xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                        + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                        + pct_16_19_2010,
                        clustervars = "county_res",
                        est_method = "reg",
                        gname = "comp_fund_first",
                          control_group = "nevertreated",
                          data = sex_ed_comp
                          
)
set.seed(1814)
comp_uw_nor <- att_gt(yname = "demn_lnbrate",
                        tname = "year",
                        idname = "county_res",
                        clustervars = "county_res",
                        est_method = "reg",
                        gname = "comp_fund_first",
                        control_group = "nevertreated",
                        data = sex_ed_comp
                        
)
set.seed(1814)
comp.uw <- aggte(comp_uw, type = "group", na.rm=TRUE)
df.comp.uw <-data.frame(comp.uw$overall.att, comp.uw$overall.se)
df.comp.uw <-janitor::clean_names(df.comp.uw)
write_dta(df.comp.uw, "folder/data/agg_group_comp_uw.dta", version = 12)

set.seed(1814)
comp.uw.nor <- aggte(comp_uw_nor, type = "group", na.rm=TRUE)
df.comp.uw.nor <-data.frame(comp.uw.nor$overall.att, comp.uw.nor$overall.se)
df.comp.uw.nor <-janitor::clean_names(df.comp.uw.nor)
write_dta(df.comp.uw.nor, "folder/data/agg_group_comp_uw_nor.dta", version = 12)

summary(comp.uw, na.rm=TRUE)

#including the boths
sex_ed_comp_both <- read.dta("folder/data/incboth_sample.dta")
set.seed(1814)
comp_both <- att_gt(yname = "demn_lnbrate",
                     tname = "year",
                     idname = "county_res",
                     gname = "comp_fund_first",
                     xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                     + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                     + pct_16_19_2010,
                     clustervars = "county_res",
                     est_method = "reg",
                     weightsname = "pop",
                     control_group = "nevertreated",
                     data = sex_ed_comp_both
                     
)

set.seed(1814)
comp_both_nor <- att_gt(yname = "demn_lnbrate",
                          tname = "year",
                          idname = "county_res",
                          gname = "comp_fund_first",
                          clustervars = "county_res",
                          est_method = "reg",
                          weightsname = "pop",
                          control_group = "nevertreated",
                          data = sex_ed_comp_both
                          
)
set.seed(1814)
summary(comp_both)
comp.both <- aggte(comp_both, type = "group", na.rm=TRUE)
df.comp.both <-data.frame(comp.both$overall.att, comp.both$overall.se)
df.comp.both<-janitor::clean_names(df.comp.both)
write_dta(df.comp.both, "folder/data/agg_group_comp_both.dta", version = 12)

set.seed(1814)
summary(comp_both_nor)
comp.both.nor <- aggte(comp_both_nor, type = "group", na.rm=TRUE)
df.comp.both.nor <-data.frame(comp.both.nor$overall.att, comp.both.nor$overall.se)
df.comp.both.nor <-janitor::clean_names(df.comp.both.nor)
write_dta(df.comp.both.nor, "folder/data/agg_group_comp_both_nor.dta", version = 12)


summary(comp.both, na.rm=TRUE)
summary(comp.both.nor, na.rm=TRUE)

set.seed(1814)
agg.dynamic.comp.both <- aggte(comp_both, type = "dynamic" , na.rm=TRUE)
ggdid(agg.dynamic.comp.both)+xlim(-15,6)
summary(agg.dynamic.comp.both)
df.agg.dynamic.comp.both <-data.frame(agg.dynamic.comp.both$egt, agg.dynamic.comp.both$att.egt, agg.dynamic.comp.both$se.egt, agg.dynamic.comp.both$crit.val.egt)
df.agg.dynamic.comp.both <-janitor::clean_names(df.agg.dynamic.comp.both)
write_dta(df.agg.dynamic.comp.both, "folder/data/agg_dynamic_comp_both.dta", version = 12)

set.seed(1814)
agg.dynamic.comp.both.nor <- aggte(comp_both_nor, type = "dynamic" , na.rm=TRUE)
ggdid(agg.dynamic.comp.both.nor)+xlim(-15,6)

set.seed(1814)
comp_both_uw <- att_gt(yname = "demn_lnbrate",
                          tname = "year",
                          idname = "county_res",
                          xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                          + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                          + pct_16_19_2010,
                          clustervars = "county_res",
                          est_method = "reg",
                          gname = "comp_fund_first",
                          control_group = "nevertreated",
                          data = sex_ed_comp_both
                          
)

set.seed(1814)
comp_both_uw_nor <- att_gt(yname = "demn_lnbrate",
                             tname = "year",
                             idname = "county_res",
                             clustervars = "county_res",
                             est_method = "reg",
                             gname = "comp_fund_first",
                             control_group = "nevertreated",
                             data = sex_ed_comp_both
                             
)

set.seed(1814)
comp.both.uw <- aggte(comp_both_uw, type = "group", na.rm=TRUE)
df.comp.both.uw <-data.frame(comp.both.uw$overall.att, comp.both.uw$overall.se)
df.comp.both.uw <-janitor::clean_names(df.comp.both.uw)
write_dta(df.comp.both.uw, "folder/data/agg_group_comp_both_uw.dta", version = 12)

set.seed(1814)
comp.both.uw.nor <- aggte(comp_both_uw_nor, type = "group", na.rm=TRUE)
df.comp.both.uw.nor <-data.frame(comp.both.uw.nor$overall.att, comp.both.uw.nor$overall.se)
df.comp.both.uw.nor <-janitor::clean_names(df.comp.both.uw.nor)
write_dta(df.comp.both.uw.nor, "folder/data/agg_group_comp_both_uw_nor.dta", version = 12)


summary(comp.both.uw, na.rm=TRUE)

#ihs
set.seed(1814)
comp_ihs <- att_gt(yname = "demn_ihs_brate",
                          tname = "year",
                          idname = "county_res",
                          gname = "comp_fund_first",
                         xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                         + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                         + pct_16_19_2010,
                         clustervars = "county_res",
                         est_method = "reg",
                         weightsname = "pop",
                          control_group = "nevertreated",
                          data = sex_ed_comp
                          
)

set.seed(1814)
comp_ihs_nor <- att_gt(yname = "demn_ihs_brate",
                         tname = "year",
                         idname = "county_res",
                         gname = "comp_fund_first",
                         clustervars = "county_res",
                         est_method = "reg",
                         weightsname = "pop",
                         control_group = "nevertreated",
                         data = sex_ed_comp
                         
)


set.seed(1814)
comp.ihs <- aggte(comp_ihs, type = "group", na.rm=TRUE)
df.comp.ihs <-data.frame(comp.ihs$overall.att, comp.ihs$overall.se)
df.comp.ihs<-janitor::clean_names(df.comp.ihs)
write_dta(df.comp.ihs, "folder/data/agg_group_comp_ihs.dta", version = 12)

set.seed(1814)
comp.ihs.nor <- aggte(comp_ihs_nor, type = "group", na.rm=TRUE)
df.comp.ihs.nor <-data.frame(comp.ihs.nor$overall.att, comp.ihs.nor$overall.se)
df.comp.ihs.nor <-janitor::clean_names(df.comp.ihs.nor)
write_dta(df.comp.ihs.nor, "folder/data/agg_group_comp_ihs_nor.dta", version = 12)


summary(comp.ihs, na.rm=TRUE)

set.seed(1814)
comp_ihs_uw <- att_gt(yname = "demn_ihs_brate",
                         tname = "year",
                         idname = "county_res",
                         xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                         + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                         + pct_16_19_2010,
                         clustervars = "county_res",
                         est_method = "reg",
                         gname = "comp_fund_first",
                         control_group = "nevertreated",
                         data = sex_ed_comp
                         
)

set.seed(1814)
comp_ihs_uw_nor <- att_gt(yname = "demn_ihs_brate",
                            tname = "year",
                            idname = "county_res",
                            clustervars = "county_res",
                            est_method = "reg",
                            gname = "comp_fund_first",
                            control_group = "nevertreated",
                            data = sex_ed_comp
                            
)

set.seed(1814)
comp.ihs.uw <- aggte(comp_ihs_uw, type = "group", na.rm=TRUE)
df.comp.ihs.uw <-data.frame(comp.ihs.uw$overall.att, comp.ihs.uw$overall.se)
df.comp.ihs.uw<-janitor::clean_names(df.comp.ihs.uw)
write_dta(df.comp.ihs.uw, "folder/data/agg_group_comp_ihs_uw.dta", version = 12)

set.seed(1814)
comp.ihs.uw.nor <- aggte(comp_ihs_uw_nor, type = "group", na.rm=TRUE)
df.comp.ihs.uw.nor <-data.frame(comp.ihs.uw.nor$overall.att, comp.ihs.uw.nor$overall.se)
df.comp.ihs.uw.nor <-janitor::clean_names(df.comp.ihs.uw.nor)
write_dta(df.comp.ihs.uw.nor, "folder/data/agg_group_comp_ihs_uw_nor.dta", version = 12)


summary(comp.ihs.uw, na.rm=TRUE)

#urban
set.seed(1814)
sex_ed_comp_urban <- read.dta("folder/data/urban_sample.dta")
comp_urban <- att_gt(yname = "demn_lnbrate",
                         tname = "year",
                         idname = "county_res",
                         xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                         + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                         + pct_16_19_2010,
                         clustervars = "county_res",
                         est_method = "reg",
                         gname = "comp_fund_first",
                         weightsname = "pop",
                         control_group = "nevertreated",
                         data = sex_ed_comp_urban
                         
)

set.seed(1814)
comp_urban_nor <- att_gt(yname = "demn_lnbrate",
                           tname = "year",
                           idname = "county_res",
                           clustervars = "county_res",
                           est_method = "reg",
                           gname = "comp_fund_first",
                           weightsname = "pop",
                           control_group = "nevertreated",
                           data = sex_ed_comp_urban
                           
)

set.seed(1814)
summary(comp_urban)
comp.urban <- aggte(comp_urban, type = "group", na.rm=TRUE)
summary(comp.urban, na.rm=TRUE)
df.comp.urban <-data.frame(comp.urban$overall.att, comp.urban$overall.se)
df.comp.urban<-janitor::clean_names(df.comp.urban)
write_dta(df.comp.urban, "folder/data/agg_group_comp_urban.dta", version = 12)

set.seed(1814)
summary(comp_urban_nor)
comp.urban.nor <- aggte(comp_urban_nor, type = "group", na.rm=TRUE)
summary(comp.urban.nor, na.rm=TRUE)
df.comp.urban.nor <-data.frame(comp.urban.nor$overall.att, comp.urban.nor$overall.se)
df.comp.urban.nor <-janitor::clean_names(df.comp.urban.nor)
write_dta(df.comp.urban.nor, "folder/data/agg_group_comp_urban_nor.dta", version = 12)

set.seed(1814)
comp_urban_uw <- att_gt(yname = "demn_lnbrate",
                           tname = "year",
                           idname = "county_res",
                           xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                           + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                           + pct_16_19_2010,
                           clustervars = "county_res",
                           est_method = "reg",
                           gname = "comp_fund_first",
                           control_group = "nevertreated",
                           data = sex_ed_comp_urban
                           
)

set.seed(1814)
comp_urban_uw_nor <- att_gt(yname = "demn_lnbrate",
                              tname = "year",
                              idname = "county_res",
                              clustervars = "county_res",
                              est_method = "reg",
                              gname = "comp_fund_first",
                              control_group = "nevertreated",
                              data = sex_ed_comp_urban
                              
)

set.seed(1814)
comp.urban.uw <- aggte(comp_urban_uw, type = "group", na.rm=TRUE)
df.comp.urban.uw <-data.frame(comp.urban.uw$overall.att, comp.urban.uw$overall.se)
df.comp.urban.uw <-janitor::clean_names(df.comp.urban.uw)
write_dta(df.comp.urban.uw, "folder/data/agg_group_comp_urban_uw.dta", version = 12)

set.seed(1814)
comp.urban.uw.nor <- aggte(comp_urban_uw_nor, type = "group", na.rm=TRUE)
df.comp.urban.uw.nor <-data.frame(comp.urban.uw.nor$overall.att, comp.urban.uw.nor$overall.se)
df.comp.urban.uw.nor <-janitor::clean_names(df.comp.urban.uw.nor)
write_dta(df.comp.urban.uw.nor, "folder/data/agg_group_comp_urban_uw_nor.dta", version = 12)


summary(comp.urban.uw, na.rm=TRUE)

#funded
set.seed(1814)
sex_ed_comp_funded <- read.dta("folder/data/forDidinR/funding_brate_nozeros_funded_1996-2017_lag1_10-11-21_oldcomp.dta")
comp_funded <- att_gt(yname = "ln_brate",
                           tname = "year",
                           idname = "county_res",
                      xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                      + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                      + pct_16_19_2010,
                      clustervars = "county_res",
                           est_method = "reg",
                           gname = "comp_fund_first",
                           weightsname = "pop",
                           control_group = "nevertreated",
                           data = sex_ed_comp_funded
                           
)

set.seed(1814)
comp_funded_nor <- att_gt(yname = "ln_brate",
                            tname = "year",
                            idname = "county_res",
                            clustervars = "county_res",
                            est_method = "reg",
                            gname = "comp_fund_first",
                            weightsname = "pop",
                            control_group = "nevertreated",
                            data = sex_ed_comp_funded
                            
)

set.seed(1814)
summary(comp_funded)
comp.funded <- aggte(comp_funded, type = "group", na.rm=TRUE)
summary(comp.funded, na.rm=TRUE)
df.comp.funded <-data.frame(comp.funded$overall.att, comp.funded$overall.se)
df.comp.funded<-janitor::clean_names(df.comp.funded)
write_dta(df.comp.funded, "folder/data/agg_group_comp_funded.dta", version = 12)

set.seed(1814)
comp.funded.nor <- aggte(comp_funded_nor, type = "group", na.rm=TRUE)
summary(comp.funded.nor)
df.comp.funded.nor <-data.frame(comp.funded.nor$overall.att, comp.funded.nor$overall.se)
df.comp.funded.nor <-janitor::clean_names(df.comp.funded.nor)
write_dta(df.comp.funded.nor, "folder/data/agg_group_comp_funded_nor.dta", version = 12)

set.seed(1814)
comp.funded.dyn <- aggte(comp_funded, type = "dynamic", na.rm=TRUE)
ggdid(comp.funded.dyn)

set.seed(1814)
comp_funded_uw <- att_gt(yname = "demn_lnbrate",
                            tname = "year",
                            idname = "county_res",
                         xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                         + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                         + pct_16_19_2010,
                         clustervars = "county_res",
                            est_method = "reg",
                            gname = "comp_fund_first",
                            control_group = "nevertreated",
                            data = sex_ed_comp_funded
                            
)

set.seed(1814)
comp_funded_uw_nor <- att_gt(yname = "ln_brate",
                               tname = "year",
                               idname = "county_res",
                               clustervars = "county_res",
                               est_method = "reg",
                               gname = "comp_fund_first",
                               control_group = "nevertreated",
                               data = sex_ed_comp_funded
                               
)

set.seed(1814)
summary(comp_funded_uw)
comp.funded.uw <- aggte(comp_funded_uw, type = "group", na.rm=TRUE)
summary(comp.funded.uw)
df.comp.funded.uw <-data.frame(comp.funded.uw$overall.att, comp.funded.uw$overall.se)
df.comp.funded.uw<-janitor::clean_names(df.comp.funded.uw)
write_dta(df.comp.funded.uw, "folder/data/agg_group_comp_funded_uw.dta", version = 12)

set.seed(1814)
comp.funded.uw.nor <- aggte(comp_funded_uw_nor, type = "group", na.rm=TRUE)
summary(comp.funded.uw.nor)
df.comp.funded.uw.nor <-data.frame(comp.funded.uw.nor$overall.att, comp.funded.uw.nor$overall.se)
df.comp.funded.uw.nor <-janitor::clean_names(df.comp.funded.uw.nor)
write_dta(df.comp.funded.uw.nor, "folder/data/agg_group_comp_funded_uw_nor.dta", version = 12)

set.seed(1814)
summary(comp.funded.uw, na.rm=TRUE)
comp.funded.dyn.uw <- aggte(comp_funded_uw, type = "dynamic", na.rm=TRUE)
summary(comp.funded.dyn.uw, na.rm=TRUE)



#excluding tx and co
set.seed(1814)
sex_ed_comp_notxco <- read.dta("folder/data/notxco.dta")
comp_notxco <- att_gt(yname = "demn_lnbrate",
                              tname = "year",
                              idname = "county_res",
                              gname = "comp_fund_first",
                            xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                            + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                            + pct_16_19_2010,
                            clustervars = "county_res",
                            est_method = "reg",
                            weightsname = "pop",
                              control_group = "nevertreated",
                              data = sex_ed_comp_notxco
                              
)

set.seed(1814)
comp_notxco_nor <- att_gt(yname = "demn_lnbrate",
                            tname = "year",
                            idname = "county_res",
                            gname = "comp_fund_first",
                            clustervars = "county_res",
                            est_method = "reg",
                            weightsname = "pop",
                            control_group = "nevertreated",
                            data = sex_ed_comp_notxco
                            
)

set.seed(1814)
comp.notxco <- aggte(comp_notxco, type = "group", na.rm=TRUE)
df.comp.notxco <-data.frame(comp.notxco$overall.att, comp.notxco$overall.se)
df.comp.notxco<-janitor::clean_names(df.comp.notxco)
write_dta(df.comp.notxco, "folder/data/agg_group_comp_notxco.dta", version = 12)

set.seed(1814)
comp.notxco.nor <- aggte(comp_notxco_nor, type = "group", na.rm=TRUE)
df.comp.notxco.nor <-data.frame(comp.notxco.nor$overall.att, comp.notxco.nor$overall.se)
df.comp.notxco.nor <-janitor::clean_names(df.comp.notxco.nor)
write_dta(df.comp.notxco.nor, "folder/data/agg_group_comp_notxco_nor.dta", version = 12)

summary(comp.notxco, na.rm=TRUE)

set.seed(1814)
comp_notxco_uw <- att_gt(yname = "demn_lnbrate",
                                 tname = "year",
                                 idname = "county_res",
                               xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                               + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                               + pct_16_19_2010,
                               clustervars = "county_res",
                               est_method = "reg",
                               gname = "comp_fund_first",
                                 control_group = "nevertreated",
                                 data = sex_ed_comp_notxco
                                 
)

set.seed(1814)
comp_notxco_uw_nor <- att_gt(yname = "demn_lnbrate",
                               tname = "year",
                               idname = "county_res",
                               clustervars = "county_res",
                               est_method = "reg",
                               gname = "comp_fund_first",
                               control_group = "nevertreated",
                               data = sex_ed_comp_notxco
                               
)

set.seed(1814)
comp.notxco.uw <- aggte(comp_notxco_uw, type = "group", na.rm=TRUE)
df.comp.notxco.uw <-data.frame(comp.notxco.uw$overall.att, comp.notxco.uw$overall.se)
df.comp.notxco.uw<-janitor::clean_names(df.comp.notxco.uw)
write_dta(df.comp.notxco.uw, "folder/data/agg_group_comp_notxco_uw.dta", version = 12)

set.seed(1814)
comp.notxco.uw.nor <- aggte(comp_notxco_uw_nor, type = "group", na.rm=TRUE)
df.comp.notxco.uw.nor <-data.frame(comp.notxco.uw.nor$overall.att, comp.notxco.uw.nor$overall.se)
df.comp.notxco.uw.nor <-janitor::clean_names(df.comp.notxco.uw.nor)
write_dta(df.comp.notxco.uw.nor, "folder/data/agg_group_comp_notxco_uw_nor.dta", version = 12)


summary(comp.notxco.uw, na.rm=TRUE)

#No NH, MT, AK
set.seed(1814)
sex_ed_comp_nonhmtak <- read.dta("folder/data/nonhmtak_sample.dta")
comp_nonhmtak <- att_gt(yname = "demn_lnbrate",
                          tname = "year",
                          idname = "county_res",
                          xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                          + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                          + pct_16_19_2010,
                          clustervars = "county_res",
                          est_method = "reg",
                          gname = "comp_fund_first",
                          weightsname = "pop",
                          control_group = "nevertreated",
                          data = sex_ed_comp_nonhmtak
                          
)
set.seed(1814)
comp_nonhmtak_nor <- att_gt(yname = "demn_lnbrate",
                              tname = "year",
                              idname = "county_res",
                              clustervars = "county_res",
                              est_method = "reg",
                              gname = "comp_fund_first",
                              weightsname = "pop",
                              control_group = "nevertreated",
                              data = sex_ed_comp_nonhmtak
                              
)
set.seed(1814)
comp.nonhmtak <- aggte(comp_nonhmtak, type = "group", na.rm=TRUE)
df.comp.nonhmtak <-data.frame(comp.nonhmtak$overall.att, comp.nonhmtak$overall.se)
df.comp.nonhmtak<-janitor::clean_names(df.comp.nonhmtak)
write_dta(df.comp.nonhmtak, "folder/data/agg_group_comp_nonhmtak.dta", version = 12)

set.seed(1814)
comp.nonhmtak.nor <- aggte(comp_nonhmtak_nor, type = "group", na.rm=TRUE)
df.comp.nonhmtak.nor <-data.frame(comp.nonhmtak.nor$overall.att, comp.nonhmtak.nor$overall.se)
df.comp.nonhmtak.nor <-janitor::clean_names(df.comp.nonhmtak.nor)
write_dta(df.comp.nonhmtak.nor, "folder/data/agg_group_comp_nonhmtak_nor.dta", version = 12)


summary(comp.nonhmtak, na.rm=TRUE)

set.seed(1814)
comp_nonhmtak_uw <- att_gt(yname = "demn_lnbrate",
                              tname = "year",
                              idname = "county_res",
                              xformla = ~pop_2010 + med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                              + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010
                              + pct_16_19_2010,
                              clustervars = "county_res",
                              est_method = "reg",
                              gname = "comp_fund_first",
                              control_group = "nevertreated",
                              data = sex_ed_comp_nonhmtak
                              
)

set.seed(1814)
nonhmtak_uw_nor <- att_gt(yname = "demn_lnbrate",
                                 tname = "year",
                                 idname = "county_res",
                                 clustervars = "county_res",
                                 est_method = "reg",
                                 gname = "comp_fund_first",
                                 control_group = "nevertreated",
                                 data = sex_ed_comp_nonhmtak
                                 
)

set.seed(1814)
comp.nonhmtak.uw <- aggte(comp_nonhmtak_uw, type = "group", na.rm=TRUE)
df.comp.nonhmtak.uw <-data.frame(comp.nonhmtak.uw$overall.att, comp.nonhmtak.uw$overall.se)
df.comp.nonhmtak.uw<-janitor::clean_names(df.comp.nonhmtak.uw)
write_dta(df.comp.nonhmtak.uw, "folder/data/agg_group_comp_nonhmtak_uw.dta", version = 12)

set.seed(1814)
nonhmtak.uw.nor <- aggte(nonhmtak_uw_nor, type = "group", na.rm=TRUE)
df.nonhmtak.uw.nor <-data.frame(nonhmtak.uw.nor$overall.att, nonhmtak.uw.nor$overall.se)
df.nonhmtak.uw.nor <-janitor::clean_names(df.nonhmtak.uw.nor)
write_dta(df.nonhmtak.uw.nor, "folder/data/agg_group_comp_nonhmtak_uw_nor.dta", version = 12)


summary(comp.nonhmtak.uw, na.rm=TRUE)

#state-level
set.seed(1814)
sex_ed_comp_st <- read.dta("folder/data/state_sample.dta")
comp_st <- att_gt(yname = "ln_brate",
                        tname = "year",
                        idname = "state_res",
                        gname = "min_comp_fund_first",
                        clustervars = "state_res",
                  xformla =  ~  med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                  + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010,                         est_method = "reg",
                        weightsname = "tot_pop",
                        control_group = "notyettreated",
                        data = sex_ed_comp_st
                        
)

set.seed(1814)
comp_st_nor <- att_gt(yname = "ln_brate",
                        tname = "year",
                        idname = "state_res",
                        gname = "min_comp_fund_first",
                        clustervars = "state_res",
                        est_method = "reg",
                        weightsname = "tot_pop",
                        control_group = "notyettreated",
                        data = sex_ed_comp_st
                        
)

set.seed(1814)
summary(comp_st)
comp.st <- aggte(comp_st, type = "group", na.rm=TRUE)
summary(comp.st)
df.comp.st <-data.frame(comp.st$overall.att, comp.st$overall.se)
df.comp.st<-janitor::clean_names(df.comp.st)
write_dta(df.comp.st, "folder/data/agg_group_comp_st.dta", version = 12)

set.seed(1814)
summary(comp_st_nor)
comp.st.nor <- aggte(comp_st_nor, type = "group", na.rm=TRUE)
summary(comp.st.nor)

df.comp.st.nor <-data.frame(comp.st.nor$overall.att, comp.st.nor$overall.se)
df.comp.st.nor<-janitor::clean_names(df.comp.st.nor)
write_dta(df.comp.st.nor, "folder/data/agg_group_comp_st_nor.dta", version = 12)

set.seed(1814)
comp.st.dyn <- aggte(comp_st, type = "dynamic", na.rm=TRUE)
summary(comp.st.dyn, na.rm=TRUE)
ggdid(comp.st.dyn)

set.seed(1814)
comp.st.dyn.nor <- aggte(comp_st_nor, type = "dynamic", na.rm=TRUE)
ggdid(comp.st.dyn.nor)

set.seed(1814)
comp_st_uw <- att_gt(yname = "ln_brate",
                           tname = "year",
                           idname = "state_res",
                           xformla =  ~  med_hhinc_i_2010 + pct_pov_i_2010 + abortion_di_2010
                           + pct_wht_2010 + pct_blk_2010 + pct_hisp_2010, 
                           control_group = "notyettreated",
                           clustervars = "state_res",
                           est_method = "reg",
                           gname = "min_comp_fund_first",
                           data = sex_ed_comp_st
                           
)

set.seed(1814)
comp_st_uw_nor <- att_gt(yname = "ln_brate",
                           tname = "year",
                           idname = "state_res",
                           control_group = "notyettreated",
                           clustervars = "state_res",
                           est_method = "reg",
                           gname = "min_comp_fund_first",
                           data = sex_ed_comp_st
                           
)
summary(comp_st_uw)

set.seed(1814)
comp.st.uw <- aggte(comp_st_uw, type = "group", na.rm=TRUE)
summary(comp.st.uw, na.rm=TRUE)

df.comp.st.uw <-data.frame(comp.st.uw$overall.att, comp.st.uw$overall.se)
df.comp.st.uw<-janitor::clean_names(df.comp.st.uw)
write_dta(df.comp.st.uw, "folder/data/agg_group_comp_st_uw.dta", version = 12)

set.seed(1814)
comp.st.uw.nor <- aggte(comp_st_uw_nor, type = "group", na.rm=TRUE)
df.comp.st.uw.nor <-data.frame(comp.st.uw.nor$overall.att, comp.st.uw.nor$overall.se)
df.comp.st.uw.nor <-janitor::clean_names(df.comp.st.uw.nor)
write_dta(df.comp.st.uw.nor, "folder/data/agg_group_comp_st_uw_nor.dta", version = 12)